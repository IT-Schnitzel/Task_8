package com.example.kudago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KudagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
